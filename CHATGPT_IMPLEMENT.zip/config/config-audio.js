export default {
  en: {
    languageCode: 'en-US',
    name: 'en-US-Neural2-D',
    audioEncoding: 'MP3'
  },
  vi: {
    languageCode: 'vi-VN',
    name: 'vi-VN-Neural2-D',
    audioEncoding: 'MP3'
  }
};
